import sys
from spectral_norm import spectral_norm

print("%0.9f" % spectral_norm(int(sys.argv[1])))
