#ifndef __FIB_H__
#define __FIB_H__

unsigned long int fib(unsigned long int);

#endif
