==============================================================================
Code Examples for O'Reilly's **Cython** by Kurt W. Smith
==============================================================================

This repository hosts the code examples for O'Reilly's *Cython: A Guide for
Python Programmers* by Kurt W. Smith.

Each top-level directory is named according to its corresponding chapter.  The
directory contents are typically numbered according to the order of the
examples in the text itself.  The names are also generally according to
section headings as well to help orientation.

Please send all questions, inquiries, or praise to <cythonbook@gmail.com>.
